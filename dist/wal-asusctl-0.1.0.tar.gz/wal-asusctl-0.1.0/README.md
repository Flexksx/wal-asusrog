# wal-asusrog
A tool that combines asusctl for ROG and TUF Asus laptops and pywal to get a nice keyboard backlight according to your background
# Dependencies
```pywal``` and ```asusctl```. Install them using your distro's package manager.
